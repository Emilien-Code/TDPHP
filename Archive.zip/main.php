<?php
    require_once('./PodcastTrack.php');
    require_once('./AlbumTrack.php');
    require_once('./AlbumTrackRenderer.php');
    require_once('./PodcastTrackRenderer.php');

    try{

        $podcastTrack = new PodcastTrack('morceau 1', "../morceau.mp3", "un mec random", "2 avril");
        $audioTrack = new AlbumTrack('morceau 2', "../morceau.mp3",  "un mec random", "2 avril");

        //echo $audioTrack->test;
        //$podcastTrack->path = -4;
        //echo $audioTrack->test;

        
        $renderer = new AlbumTrackRenderer($audioTrack);
        echo $renderer->render(1);
        $renderer = new PodcastTrackRenderer($podcastTrack);
        echo $renderer->render(0);

    }catch(InvalidPropertyNameException | Exception $e){

        echo 'Exception reçue : ',  $e->getMessage(), "\n";

    }
