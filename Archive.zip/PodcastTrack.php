<?php
    require_once('./AlbumTrack.php');
    class PodcastTrack extends AlbumTrack{

        protected $genre;
        protected $duree;


        public function __construct(string $titre, string $path, string $artiste, string $date){

            parent::__construct($titre, $path, $artiste, $date);
            $this->genre = "initial value";
            $this->duree = "initial value";

        }

    }